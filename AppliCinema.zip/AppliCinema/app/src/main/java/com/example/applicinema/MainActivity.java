package com.example.applicinema;

import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.provider.BaseColumns;
import android.view.View;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.applicinema.databinding.ActivityMainBinding;

import android.view.Menu;
import android.view.MenuItem;
import android.widget.Button;

import java.sql.Time;
import java.sql.Timestamp;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    private AppBarConfiguration appBarConfiguration;
    private ActivityMainBinding binding;
    private SQLiteDatabase mDb;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);

        binding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        setSupportActionBar(binding.toolbar);

        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        appBarConfiguration = new AppBarConfiguration.Builder(navController.getGraph()).build();
        NavigationUI.setupActionBarWithNavController(this, navController, appBarConfiguration);
    }




    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu_main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        int id = item.getItemId();

        //noinspection SimplifiableIfStatement
        if (id == R.id.action_settings) {
            return true;
        }

        return super.onOptionsItemSelected(item);
    }

    @Override
    public boolean onSupportNavigateUp() {
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_content_main);
        return NavigationUI.navigateUp(navController, appBarConfiguration)
                || super.onSupportNavigateUp();
    }

    public class WaitlistContract {

        public final class WaitlistEntry implements BaseColumns {

            public static final String TABLE_NAME = "critiques_cinema";
            public static final String COLUMN_TITRE = "titre";
            public static final String COLUMN_DATE = "date";
            public static final String COLUMN_HEURE = "heure";
            public static final String COLUMN_NOTE_SCENARIO = "note_scenario";
            public static final String COLUMN_NOTE_REAL = "note_real";
            public static final String COLUMN_NOTE_MUSIQUE = "note_musique";
            public static final String COLUMN_CRITIQUE = "critique";
        }

    }
    public void onCreate(SQLiteDatabase sqLiteDatabase) {

        final String SQL_CREATE_WAITLIST_TABLE = "CREATE TABLE " + WaitlistContract.WaitlistEntry.TABLE_NAME + " (" +
                WaitlistContract.WaitlistEntry._ID + " INTEGER PRIMARY KEY AUTOINCREMENT," +
                WaitlistContract.WaitlistEntry.COLUMN_TITRE + " TEXT NOT NULL, " +
                WaitlistContract.WaitlistEntry.COLUMN_DATE + " TIMESTAMP DEFAULT CURRENT_DATE, " +
                WaitlistContract.WaitlistEntry.COLUMN_HEURE + " TIMESTAMP DEFAULT CURRENT_TIME," +
                WaitlistContract.WaitlistEntry.COLUMN_NOTE_SCENARIO + " INTEGER NOT NULL, " +
                WaitlistContract.WaitlistEntry.COLUMN_NOTE_REAL + " INTEGER NOT NULL," +
                WaitlistContract.WaitlistEntry.COLUMN_NOTE_MUSIQUE + " INTEGER NOT NULL," +
                WaitlistContract.WaitlistEntry.COLUMN_CRITIQUE + " TEXT NOT NULL " +
                "); ";

        sqLiteDatabase.execSQL(SQL_CREATE_WAITLIST_TABLE);
    }

    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        // In a production app, this method might be modified to ALTER the table
        // instead of dropping it, so that existing data is not deleted.
        sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + WaitlistContract.WaitlistEntry.TABLE_NAME);
        onCreate(sqLiteDatabase);
    }

    private long addNewCritique(String titre, Timestamp date, Timestamp heure, Integer noteScenario, Integer noteReal, Integer noteMusique, String critique) {
        // instance to pass the values onto the insert query
        ContentValues cv = new ContentValues();
        cv.put(WaitlistContract.WaitlistEntry.COLUMN_TITRE, titre);
        cv.put(WaitlistContract.WaitlistEntry.COLUMN_DATE, String.valueOf(date));
        cv.put(WaitlistContract.WaitlistEntry.COLUMN_HEURE, String.valueOf(heure));
        cv.put(WaitlistContract.WaitlistEntry.COLUMN_NOTE_SCENARIO, noteScenario);
        cv.put(WaitlistContract.WaitlistEntry.COLUMN_NOTE_REAL, noteReal);
        cv.put(WaitlistContract.WaitlistEntry.COLUMN_NOTE_MUSIQUE, noteMusique);
        cv.put(WaitlistContract.WaitlistEntry.COLUMN_CRITIQUE, critique);

        return mDb.insert(WaitlistContract.WaitlistEntry.TABLE_NAME, null, cv);
    }

    Button clickButton = (Button) findViewById(R.id.btnEnvoyer);
    clickButton.OnClickListener( new OnClickListener() {

        @Override
        public void onClick(View v) {
            addNewCritique(R.id.titreText.toString(), R.id.dateProjection.toString(), R.id.heureProjection.toString(), R.id.txtNote.toString(), R.id.txtNote2.toString(), R.id.txtNote3.toString(), R.id.txtCritique.toString())
        }
    });

}